#include "paardenwidget.h"
#include "ui_paardenwidget.h"
#include <zmq.hpp>
#include <QMessageBox>
#include <string>

PaardenWidget::PaardenWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PaardenWidget)
{
    ui->setupUi(this);
}

PaardenWidget::~PaardenWidget()
{
    delete ui;
}

void PaardenWidget::on_startRaceButton_clicked()
{
    bool ok;
    int gok = ui->lineEdit->text().toInt(&ok);
    if (!ok || gok < 1 || gok > 5) {
        ui->raceResultLabel_->setText("Geef een getal tussen 1 en 5.");
        return;
    }

    // Lees gebruikersnaam
    gebruikersnaam = ui->naamInput->text();
    if (gebruikersnaam.isEmpty()) gebruikersnaam = "QtUser";

    // Stuur gok naar Benternet met gebruikersnaam
    zmq::context_t context{1};
    zmq::socket_t push_socket{context, zmq::socket_type::push};
    zmq::socket_t sub_socket{context, zmq::socket_type::sub};

    push_socket.connect("tcp://benternet.pxl-ea-ict.be:24041");
    sub_socket.connect("tcp://benternet.pxl-ea-ict.be:24042");

    std::string sub_topic = "paardenrace!>" + gebruikersnaam.toStdString() + ">";
    sub_socket.setsockopt(ZMQ_SUBSCRIBE, sub_topic.c_str(), sub_topic.length());

    std::string bericht = "paardenrace?>" + gebruikersnaam.toStdString() + ">" + std::to_string(gok);
    push_socket.send(zmq::buffer(bericht), zmq::send_flags::none);

    zmq::message_t antwoord;
    sub_socket.recv(antwoord, zmq::recv_flags::none);
    std::string response = antwoord.to_string();

    ui->raceResultLabel_->setText(QString::fromStdString(response));
}

void PaardenWidget::on_backButton_clicked()
{
    emit backToMain();
}
