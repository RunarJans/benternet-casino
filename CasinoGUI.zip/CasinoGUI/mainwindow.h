#pragma once
#include <zmq.hpp>
#include <QTimer>
#include <QMainWindow>
#include "customdicewidget.h"
#include "paardenwidget.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private slots:
    void on_customDiceButton_clicked();
    void on_Paardenrace_clicked();
    void showMainWindow();
    void checkHeartbeats();
    void checkLogs(); // ⬅️ nieuw
    void checkWeer(); // nieuwe slotfunctie


private:
    Ui::MainWindow* ui;
    CustomDiceWidget* diceWindow = nullptr;
    PaardenWidget* paardWindow = nullptr;

                zmq::context_t context{1};
    zmq::socket_t sub_socket{context, zmq::socket_type::sub};      // voor heartbeat
    zmq::socket_t log_sub{context, zmq::socket_type::sub};         // ⬅️ voor logs
    QTimer* heartbeatTimer = nullptr;
    QTimer* logTimer = nullptr;                                    // ⬅️ voor log polling
    zmq::socket_t weer_sub{context, zmq::socket_type::sub}; // weather socket
    QTimer* weerTimer = nullptr;
};
