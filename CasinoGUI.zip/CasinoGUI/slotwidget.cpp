#include "slotwidget.h"
#include "ui_slotwidget.h"

SlotWidget::SlotWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SlotWidget)
{
    ui->setupUi(this);
}

SlotWidget::~SlotWidget()
{
    delete ui;
}
