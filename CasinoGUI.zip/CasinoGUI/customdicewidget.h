#pragma once

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class CustomDiceWidget; }
QT_END_NAMESPACE

class CustomDiceWidget : public QWidget {
    Q_OBJECT

public:
    explicit CustomDiceWidget(QWidget* parent = nullptr);
    ~CustomDiceWidget();

signals:
    void backToMain(); // voor terugkeer

private slots:
    void on_rollButton_clicked();
    void on_backButton_clicked();

private:
    Ui::CustomDiceWidget* ui;
};
