#pragma once

#include <QWidget>

namespace Ui {
class PaardenWidget;
}

class PaardenWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PaardenWidget(QWidget *parent = nullptr);
    ~PaardenWidget();

    void setGebruikersnaam(const QString& naam);  // Voeg dit toe om de naam door te geven

signals:
    void backToMain();

private slots:
    void on_startRaceButton_clicked();
    void on_backButton_clicked();

private:
    Ui::PaardenWidget *ui;
    QString gebruikersnaam;  // Nieuw veld
};
