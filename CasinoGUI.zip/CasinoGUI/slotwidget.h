#ifndef SLOTWIDGET_H
#define SLOTWIDGET_H

#include <QWidget>

namespace Ui {
class SlotWidget;
}

class SlotWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SlotWidget(QWidget *parent = nullptr);
    ~SlotWidget();

private:
    Ui::SlotWidget *ui;
};

#endif // SLOTWIDGET_H
