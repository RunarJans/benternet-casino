#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <zmq.hpp>
#include <QTimer>
#include <QDebug>
#include <QFile>
#include <QTextStream>
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // ⏺ Heartbeat socket
    sub_socket.connect("tcp://benternet.pxl-ea-ict.be:24042");
    const std::string hb_filter = "heartbeat!>";
    sub_socket.setsockopt(ZMQ_SUBSCRIBE, hb_filter.c_str(), hb_filter.size());

    // 🕒 Heartbeat timer
    heartbeatTimer = new QTimer(this);
    connect(heartbeatTimer, &QTimer::timeout, this, &MainWindow::checkHeartbeats);
    heartbeatTimer->start(2000);

    log_sub.connect("tcp://benternet.pxl-ea-ict.be:24042");
    const std::string log_filter = "log!>";
    log_sub.setsockopt(ZMQ_SUBSCRIBE, log_filter.c_str(), log_filter.size());

    logTimer = new QTimer(this);
    connect(logTimer, &QTimer::timeout, this, &MainWindow::checkLogs);
    logTimer->start(1000);

    // 📡 Weer socket
    weer_sub.connect("tcp://benternet.pxl-ea-ict.be:24042");
    const std::string weer_filter = "weer!>";
    weer_sub.setsockopt(ZMQ_SUBSCRIBE, weer_filter.c_str(), weer_filter.size());

    // ⏱️ Weer timer
    weerTimer = new QTimer(this);
    connect(weerTimer, &QTimer::timeout, this, &MainWindow::checkWeer);
    weerTimer->start(2000); // elke 2 seconden

}


MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_customDiceButton_clicked() {
    diceWindow = new CustomDiceWidget();
    connect(diceWindow, &CustomDiceWidget::backToMain, this, &MainWindow::showMainWindow);
    diceWindow->show();
    this->hide();
}

void MainWindow::on_Paardenrace_clicked() {
    paardWindow = new PaardenWidget();
    connect(paardWindow, &PaardenWidget::backToMain, this, &MainWindow::showMainWindow);
    paardWindow->show();
    this->hide();
}


void MainWindow::showMainWindow() {
    this->show();
    if (diceWindow) {
        diceWindow->close();
        diceWindow->deleteLater();
        diceWindow = nullptr;
    }
    if (paardWindow) {
        paardWindow->close();
        paardWindow->deleteLater();
        paardWindow = nullptr;
    }
}

void MainWindow::checkHeartbeats() {
    zmq::message_t msg;
    while (sub_socket.recv(msg, zmq::recv_flags::dontwait)) {
        std::string data = msg.to_string();
        qDebug() << "Ontvangen heartbeat:" << QString::fromStdString(data);

        if (data.find("heartbeat!>custom_dice") != std::string::npos) {
            ui->customDiceStatusLabel->setText("Actief");
        }
        if (data.find("heartbeat!>paardenrace") != std::string::npos) {
            ui->paardenStatusLabel->setText("Actief");
        }
    }
}

void MainWindow::checkLogs() {
    zmq::message_t msg;
    while (log_sub.recv(msg, zmq::recv_flags::dontwait)) {
        std::string log = msg.to_string();
        QString qlog = QString::fromStdString(log);


                    //  Toon in UI
                    ui->logTextEdit->append(qlog);

        //  Schrijf naar bestand
        QFile file("log.txt");
        if (file.open(QIODevice::Append | QIODevice::Text)) {
            QTextStream out(&file);
            out << qlog << "\n";
        }
    }
}

void MainWindow::checkWeer() {
    zmq::message_t msg;
    while (weer_sub.recv(msg, zmq::recv_flags::dontwait)) {
        std::string data = msg.to_string();
        QString weerinfo = QString::fromStdString(data.substr(6)); // skip "weer!>"
        ui->weerLabel->setText(weerinfo); // zorg dat dit label bestaat in de UI
    }
}
