#include "customdicewidget.h"
#include "ui_customdicewidget.h"
#include <zmq.hpp>
#include <string>
#include <random>

CustomDiceWidget::CustomDiceWidget(QWidget* parent)
    : QWidget(parent)
    , ui(new Ui::CustomDiceWidget)
{
    ui->setupUi(this);
}

CustomDiceWidget::~CustomDiceWidget() {
    delete ui;
}

void CustomDiceWidget::on_rollButton_clicked() {
    QString input = ui->sidesEdit->text();
    bool ok;
    int sides = input.toInt(&ok);




        if (!ok || sides < 1 || sides > 1000000) {
        ui->resultLabel_->setText("Invalid number of sides.");
        return;
    }

    zmq::context_t context{1};
    zmq::socket_t push_socket{context, zmq::socket_type::push};
    zmq::socket_t sub_socket{context, zmq::socket_type::sub};

    push_socket.connect("tcp://benternet.pxl-ea-ict.be:24041");
    sub_socket.connect("tcp://benternet.pxl-ea-ict.be:24042");

    QString gebruiker = "QtGUI";
    std::string sub_topic = "custom_dice!>" + gebruiker.toStdString() + ">";
    sub_socket.setsockopt(ZMQ_SUBSCRIBE, sub_topic.c_str(), sub_topic.length());

    std::string msg = "custom_dice?>" + gebruiker.toStdString() + ">d" + std::to_string(sides);
    push_socket.send(zmq::buffer(msg), zmq::send_flags::none);

    zmq::message_t antwoord;
    sub_socket.recv(antwoord, zmq::recv_flags::none);
    std::string response = antwoord.to_string();

    ui->resultLabel_->setText(QString::fromStdString(response));
}

void CustomDiceWidget::on_backButton_clicked() {
    emit backToMain();
}
